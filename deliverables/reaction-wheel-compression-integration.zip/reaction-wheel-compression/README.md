# 动量轮数据压缩传输集成说明

交付日期：2026-10-16。基于本次上传的 DataCompress_System 六个分卷及 balanced-cube-v1.02 工程实现。

本包交付的是可验证的软件集成版本：固件源码已接入，上位机程序已构建，协议、模拟串口和页面已验证。尚未进行真实 AT32 板上的 Keil 完整编译、烧录、电机运行和控制周期测量，不应将软件测试结果视为实机验收。

## 1. 集成方式

```text
AT32F403A 动量轮
  原有 IMU / 编码器 / FOC 控制
           ↓ 读取遥测，默认 100 Hz
  无损 ZRLE 压缩；无收益则 RAW
           ↓ DCW1 + 序号 + 时间 + CRC16
  USART3 DMA，230400 / 8N1
           ↓ USB-TTL
Python 串口采集程序
  串口原始记录 + 独立网络工作线程
           ↓ HTTP：仍然上传压缩二进制帧
Java 后端 /api/wheel/frames
  校验 → 解压 → 统计 → 最近数据缓存
           ↓ 现有系统网关
Vue “动量轮遥测”页面 /wheel

配置方向：页面 → Java → Python → CW1 串口配置 → 固件
确认方向：固件在后续 DCW1 帧中回传实际模式、周期 → 页面
```

Java/Vue 系统继续在电脑运行。单片机新增的是固定内存、独立分帧的压缩和遥测模块；原系统的 ZSTD、LZMA、LSTM 等 Java 组件没有移植到单片机。

通过 `--backend http://接收电脑IP:8082`，也可将串口电脑收到的压缩帧传到另一台运行 Java 后端的电脑，解压在后端执行。无需先在串口电脑解压再上传。

## 2. 目录

| 路径 | 用途 |
|---|---|
| `firmware/USER/AT32F403A.uvprojx` | 已加入新模块的 Keil 工程 |
| `firmware/UserFile/WheelCodec.*` | 独立 C 无损编码与 CRC |
| `firmware/UserFile/WheelTelemetry.*` | 采集、节流、DMA 忙处理、遥测配置解析 |
| `DataCompress_System/` | 修改后的完整系统源码，含后端 JAR、前端 dist 和网关依赖 |
| `serial-agent/wheel_agent.py` | 实时串口采集、记录、上传及历史回放 |
| `serial-agent/wheel_protocol.py` | 帧解析、CRC 校验及配置报文 |
| `examples/historical-gyro.*` | 附件历史 CSV 前 1000 行及对应 DCW1 回放文件 |
| `tests/` | 协议测试、MCU 调度桩测试、端到端结果和页面截图 |
| `验证报告.md` | 已完成测试及硬件验收边界 |

未携带原工程的旧 `.bin`、`.axf`、`.o` 等固件产物，避免与集成后的源码混用。原作者的许可证、源码注释及 FOC 库保留。

## 3. 先在电脑上验证

需要 Java 17、Node.js 18.17 或更新版本、Python 3.9 或更新版本。本包已包含后端 JAR、前端 dist、网关纯 JavaScript 运行依赖；无需先安装 Maven 或重新构建界面。

Windows 在解压后的根目录执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\DataCompress_System\run.ps1
```

访问 `http://localhost:8080/wheel`。原有传输监控、策略分析和效果展示入口保留。

另开终端回放历史数据：

```powershell
python .\serial-agent\wheel_agent.py --replay .\examples\historical-gyro.dcw --backend http://127.0.0.1:8082 --pace 0.2
```

此回放不依赖 pyserial，也不打开串口。页面会显示“历史回放”；回放结束约 3 秒后状态变为等待设备，最近数据仍可查看和导出。

历史文件仍为附件的旧通道布局：只有 gyro_x/y/z 和末尾遥控通道具有原始意义，中间预留通道为零。示例的设备时间按 10 ms 间隔重新生成，仅用于链路回放，不能作为原始采样时序或轮速、电流实测记录。

Linux/macOS 可分两个终端启动同一套上位机服务：

```bash
cd DataCompress_System/backend
java -jar target/data-compress-control-system-v5-5.0.0.jar --server.port=8082 --app.network.simulation-enabled=false
```

```bash
cd DataCompress_System/bridge
node src/server.mjs
```

原系统其他页面的网络仿真设置沿用原逻辑；新增动量轮页只统计实际上传的 DCW1 帧，回放数据会标明来源。

## 4. 接上动量轮

1. 用 Keil µVision 打开 `firmware/USER/AT32F403A.uvprojx`。原工程采用 ARMCC 5.06，器件为 AT32F403ARCT7，设备包为 ArteryTek.AT32F403A_407_DFP；FOC `.lib` 沿用原工程。先完成本地完整编译并检查 RAM、Flash 和链接结果，再按原板卡流程烧录。
2. 使用 **3.3 V 电平** USB-TTL：板端 PB10/USART3_TX 接适配器 RX，PB11/USART3_RX 接适配器 TX，两端 GND 相连。串口为 230400、8 数据位、无校验、1 停止位。板卡电源沿用原硬件配置。
3. 安装串口依赖并启动采集，把 COM4 换成实际串口：

```powershell
python -m pip install -r .\serial-agent\requirements.txt
python .\serial-agent\wheel_agent.py --port COM4 --enable-stream --backend http://127.0.0.1:8082
```

Linux 示例：

```bash
python serial-agent/wheel_agent.py --port /dev/ttyUSB0 --enable-stream --backend http://127.0.0.1:8082
```

`--enable-stream` 仅发送原工程的 `A0 AC 08 BA 66` 开启遥测命令。后续配置只使用新定义的 CW1 报文，不发送电机校准、起立、转动或电源命令。该选项在程序启动时发送一次；设备断电重启后，如遥测未开启，请重新启动采集程序。

串口由采集程序独占，关闭占用同一串口的原调试助手。新遥测协议替代旧 `0x23 + 16 float + sum` 输出，原 `parse_debug.py` 不适用于新固件。

4. 打开 `/wheel`，选择 AUTO 或 RAW，周期填写 10~1000 ms。采集程序约每 2 秒取一次配置，固件回传实际模式与周期后页面显示“设备已确认当前配置”。离线或历史回放时不会显示已应用。
5. 页面验证角速度、姿态、轮速、电流、电池电压随设备状态变化，并核对实测量纲和标定。固件只是读取这些变量；没有修改 PID/FOC 参数、遥控逻辑或电机输出。

## 5. 采集与时序

默认周期 10 ms，最高 100 Hz；配置不改变原 1 ms 调度和电机中断频率。压缩在原主循环中平衡控制代码之后执行；定时器中断只增加毫秒计数。

最坏一帧为 86 字节，小于原串口 DMA 缓冲区 128 字节。100 Hz 时占用 8600 字节/秒，按 8N1 计约 86000 bit/s，为 230400 波特率的 37.3%。这是协议带宽计算，不是实时性能实测。

DMA 忙时跳过该遥测槽，不等待 DMA，不突发补发过期采样；序号可反映缺口。发送函数增加了长度和忙状态检查，防止遥测覆盖正在发送的数据。共享串口上的原校准应答在 DMA 忙时也可能无法即时发出，需要避开持续遥测进行原校准流程。

| 通道（从 1 开始） | 固件变量 | 量纲 |
|---|---|---|
| 1~3 | `mpu6500.gyro.filter.x/y/z` | 原工程角速度，°/s |
| 4~6 | `mpu6500.gyroAngle.x/y/z` | 原工程姿态角，° |
| 7~9 | `M1/2/3_Encoder.Speed_filter` | 原计算式对应 °/s；RPM = 数值 / 6 |
| 10~12 | `M1/2/3_Foc.Iq` | 原 FOC 电流量，按板卡标定确认 |
| 13 | `Cubli.BatVin` | V |
| 14 | `Cubli.Protect_flag` | 状态值，转为 float |
| 15~16 | `Rc.x_f/y_f` | 原遥控输入单位 |

保留 16 个 float32 的原始位模式，不进行有损量化。各通道读取发生在同一次遥测函数中，但不关闭控制中断，不保证全部传感器变量来自同一硬件采样瞬间。

## 6. 协议

所有多字节整数采用小端序，float 为 AT32 上的 IEEE754 float32、小端序。

| 偏移 | 字节数 | 含义 |
|---:|---:|---|
| 0 | 4 | ASCII `DCW1`，含协议版本 |
| 4 | 1 | 实际编码：0=RAW，1=ZRLE |
| 5 | 1 | 通道数，固定 16 |
| 6 | 2 | 编码载荷长度 N，1~64 |
| 8 | 4 | 遥测采样槽序号，uint32 |
| 12 | 4 | 设备毫秒计数，uint32 |
| 16 | 1 | 已应用模式：0=RAW，1=AUTO |
| 17 | 2 | 已应用周期，10~1000 ms |
| 19 | 1 | 保留，固定 0 |
| 20 | N | 载荷，解压后固定 64 字节 |
| 20+N | 2 | 对前 20+N 字节计算的 CRC16 |

CRC 为 CRC-16/CCITT-FALSE：多项式 0x1021，初值 0xFFFF，不反射，xorout=0，`123456789` 校验值为 0x29B1。

ZRLE token 的最高位为 1 表示零字节段，最高位为 0 表示后接字面字节段；段长均为 `(token & 0x7F) + 1`。每帧独立恢复，无跨帧字典。编码载荷达不到小于 64 字节时，AUTO 自动回退 RAW。

配置帧固定 8 字节：`43 57 01 mode period_lo period_hi crc_lo crc_hi`。CRC 覆盖前 6 字节。mode 仅允许 0/1，周期仅允许 10~1000；解析器支持串口分段输入。应用配置后通过后续遥测头确认，不另发应答帧。

## 7. 后端接口与数据留存

| 方法与路径 | 作用 |
|---|---|
| `POST /api/wheel/frames` | 接收完整帧批次，Content-Type 为 application/octet-stream |
| `GET /api/wheel/status` | 在线状态、最近数据、累计字节、缺口和配置确认 |
| `GET /api/wheel/config` | 采集程序读取期望配置 |
| `PUT /api/wheel/config` | JSON：`{"mode":"AUTO","periodMs":10}` |
| `GET /api/wheel/history?limit=200` | 当前采集会话最近样本，最多 4000 帧 |
| `GET /api/wheel/export.csv` | 导出当前会话最近样本 |

上传需带 `X-Wheel-Batch-Id` 和 `X-Wheel-Session`；本代理自动生成。每批最多 65536 字节，整批校验成功后再入库；最近 256 个批次 ID 的重复请求不会重复计数。这里只使用内存缓存，服务重启后统计和配置恢复默认值。

更换采集会话或判定设备重启时清空当前曲线缓存，避免连接不同时间轴；累计统计保留到服务重启。当前版本按一个动量轮数据源设计，请勿同时用多个采集程序向同一后端交错上传。

串口程序默认创建 `runtime/wheel-UTC时间.dcw`，也可通过 `--record 路径` 指定，已存在文件不会覆盖。记录包括收到的原始字节，CRC 错误和串口应答也会保留；回放时重新同步并只上传有效帧。

网络上传与串口读取分开。网络断开时当前批次重试，待传队列最多 100 批；队列满后不会阻塞串口，会在日志报告未上传帧数。完整记录可在恢复后通过 `--replay` 补传。停止程序时未发送完的内存队列同样依靠原始记录恢复；这不是磁盘持久化消息队列，也没有串口链路自动重传。

校验失败候选数在串口程序日志中查看；页面的“拒绝批次”是后端拒绝的请求数。序号缺口可能来自 DMA 忙、主循环调度延迟、串口错误或上传丢弃，不等同于网络丢包率。页面两种节省比例分别对比 64 字节原始载荷及 86 字节同协议 RAW 整帧，不能直接当作相对旧 66 字节协议的收益。

## 8. 重新构建与验证

上位机：

```powershell
cd DataCompress_System\backend
mvn test package
cd ..\frontend
npm ci
npm run build
```

前端和网关锁文件的下载地址已由附件中的镜像域名改为官方 npm registry，依赖版本及完整性摘要保留。前端开发服务器增加了 `/api` 到本机 8082 的代理。

协议及调度测试需 GCC：

```bash
python tests/test_protocol.py
mkdir -p tests/build
gcc -std=c99 -Wall -Wextra -Werror -D__app_H -include tests/mcu_stubs.h -Ifirmware/UserFile firmware/UserFile/WheelCodec.c firmware/UserFile/WheelTelemetry.c tests/test_telemetry.c -o tests/build/test_telemetry
./tests/build/test_telemetry
```

启动上位机后，可在 Linux、安装 pyserial 的 Python 环境中运行 `python tests/e2e.py`，验证实际 HTTP 与伪终端串口链路。

云环境验证时，原有 Spring 测试所用 Mockito 无法动态附加 JVM agent，因此使用显式 Byte Buddy `-javaagent` 运行完整 Maven 测试；没有跳过测试。普通本地 JDK 通常不需要此参数。

实机验收仍需完成：Keil 完整编译与内存占用核查；示波器/串口记录核对帧和波特率；DWT 或 GPIO 测量压缩和主循环最坏执行时间；确认 DMA/FOC 中断时序；在实际 16 通道和典型运动状态下测量压缩率、序号缺口、端到端延时及控制稳定性。
