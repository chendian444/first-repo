# 工业网络数据传输智能诊断与预测系统

保持整个交付目录结构，双击本目录 `启动.bat`，或在 `three-systems` 根目录执行 `node scripts/start.mjs prediction`。界面端口为 8103。

源码、共用依赖、指标含义、构建与运行说明见 [总体说明](../../README.md)。
