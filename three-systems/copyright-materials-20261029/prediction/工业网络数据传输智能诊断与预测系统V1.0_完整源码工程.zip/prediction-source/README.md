# 工业网络数据传输智能诊断与预测系统 V1.0 单系统源码

本工程固定为 `prediction` 入口，仅包含本系统的主视图与构建配置；压缩、传输、遥测等公共底层依赖随本工程完整提供，不依赖另外两套系统的源码目录。公共实现仍与原仓库共源，不表示重新实现了三套不同的底层算法。

开发环境：JDK 17+、Maven 3.9+、Node.js 18.17+、npm。

在根目录运行 `sh scripts/build.sh`，会安装Node依赖、构建本系统界面并生成后端JAR。Windows请按原脚本内容依次执行对应Node、npm及Maven命令。构建完成后运行 `node scripts/start.mjs prediction`；停止运行 `node scripts/stop.mjs prediction`。

界面/后端/接收端端口：8103/8203/8303。运行数据生成于 `runtime/prediction`，本源码包未包含运行数据或依赖目录。
