export const softwareConfigs = {
  prediction: { port: 8103, backendPort: 8203, receiverPort: 8303 }
}
export function softwareConfig(kind) {
  if (!Object.hasOwn(softwareConfigs, kind)) throw new Error('Specify prediction')
  return softwareConfigs[kind]
}
