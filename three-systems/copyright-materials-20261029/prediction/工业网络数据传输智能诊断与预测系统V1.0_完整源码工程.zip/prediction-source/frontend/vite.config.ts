import { fileURLToPath, URL } from 'node:url'

import vue from '@vitejs/plugin-vue'
import { defineConfig } from 'vite'

const softwareTitle = '工业网络数据传输智能诊断与预测系统'

export default defineConfig(({ mode }) => ({
  plugins: [vue(), {
    name: 'software-html-title',
    transformIndexHtml(html) {
      return html.replace(/<title>.*?<\/title>/, `<title>${softwareTitle}</title>`)
    }
  }],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  server: {
    host: '0.0.0.0',
    port: 5173
  }
}))
