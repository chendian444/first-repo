export const software = 'prediction'
export const softwareTitle = '工业网络数据传输智能诊断与预测系统'
