export const softwareConfigs = {
  monitor: { port: 8101, backendPort: 8201, receiverPort: 8301 },
}
export function softwareConfig(kind) {
  if (!Object.hasOwn(softwareConfigs, kind)) throw new Error('Specify monitor')
  return softwareConfigs[kind]
}
