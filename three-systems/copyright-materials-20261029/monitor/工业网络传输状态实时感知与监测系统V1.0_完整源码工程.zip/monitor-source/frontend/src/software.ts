export const software = 'monitor'
export const softwareTitle = '工业网络传输状态实时感知与监测系统'
