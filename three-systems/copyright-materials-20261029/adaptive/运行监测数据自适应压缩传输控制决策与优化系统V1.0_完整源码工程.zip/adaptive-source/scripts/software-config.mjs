export const softwareConfigs = {
  adaptive: { port: 8102, backendPort: 8202, receiverPort: 8302 },
}
export function softwareConfig(kind) {
  if (!Object.hasOwn(softwareConfigs, kind)) throw new Error('Specify adaptive')
  return softwareConfigs[kind]
}
