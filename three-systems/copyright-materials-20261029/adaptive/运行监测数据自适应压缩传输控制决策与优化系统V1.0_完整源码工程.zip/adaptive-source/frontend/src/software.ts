export const software = 'adaptive'
export const softwareTitle = '运行监测数据自适应压缩传输控制决策与优化系统'
